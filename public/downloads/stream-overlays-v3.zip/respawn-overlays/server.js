/**
 * RESPAWN ØSTFOLD — Overlay WebSocket Server
 * 
 * Start med: node server.js
 * Kontrollpanel: http://localhost:3000/KONTROLLPANEL.html
 * Overlays i OBS: http://localhost:3000/04_nameplates.html osv.
 */

const http = require('http');
const fs   = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');

const PORT = 3000;
const DIR  = __dirname;

// ── Siste kjente state (ny klient får dette ved tilkobling) ──
let state = {
  scene:       '',
  match:       null,
  commentator: null,
  interview:   null,
  bracket:     null,
  countdown:   null,
};

// ── MIME types ──
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css':  'text/css',
  '.js':   'application/javascript',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.ico':  'image/x-icon',
  '.md':   'text/plain',
};

// ── HTTP server (serves overlay HTML files) ──
const server = http.createServer((req, res) => {
  let urlPath = req.url.split('?')[0];
  if (urlPath === '/' || urlPath === '') urlPath = '/KONTROLLPANEL.html';

  const filePath = path.join(DIR, urlPath);

  // Security: only serve files inside DIR
  if (!filePath.startsWith(DIR)) {
    res.writeHead(403); res.end('Forbidden'); return;
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not found: ' + urlPath);
      return;
    }
    const ext  = path.extname(filePath);
    const mime = MIME[ext] || 'application/octet-stream';
    res.writeHead(200, {
      'Content-Type': mime,
      'Cache-Control': 'no-cache',
    });
    res.end(data);
  });
});

// ── WebSocket server ──
const wss = new WebSocketServer({ server });

wss.on('connection', (ws) => {
  console.log('[WS] Klient koblet til. Totalt:', wss.clients.size);

  // Send current state to new client immediately
  ws.send(JSON.stringify({ type: 'init', state }));

  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw);
      console.log('[WS] Melding:', msg.type, JSON.stringify(msg.data).slice(0, 80));

      // Update state
      if (msg.type === 'scene')       state.scene       = msg.data;
      if (msg.type === 'match')       state.match       = msg.data;
      if (msg.type === 'commentator') state.commentator = msg.data;
      if (msg.type === 'interview')   state.interview   = msg.data;
      if (msg.type === 'bracket')     state.bracket     = msg.data;
      if (msg.type === 'countdown')   state.countdown   = msg.data;

      // Broadcast to ALL connected clients (including sender)
      const out = JSON.stringify({ type: msg.type, data: msg.data });
      wss.clients.forEach((client) => {
        if (client.readyState === 1) client.send(out);
      });
    } catch (e) {
      console.error('[WS] Parse error:', e.message);
    }
  });

  ws.on('close', () => {
    console.log('[WS] Klient koblet fra. Totalt:', wss.clients.size);
  });
});

server.listen(PORT, () => {
  console.log('');
  console.log('  ██████╗ ███████╗███████╗██████╗  █████╗ ██╗    ██╗███╗   ██╗');
  console.log('  ██╔══██╗██╔════╝██╔════╝██╔══██╗██╔══██╗██║    ██║████╗  ██║');
  console.log('  ██████╔╝█████╗  ███████╗██████╔╝███████║██║ █╗ ██║██╔██╗ ██║');
  console.log('  ██╔══██╗██╔══╝  ╚════██║██╔═══╝ ██╔══██║██║███╗██║██║╚██╗██║');
  console.log('  ██║  ██║███████╗███████║██║     ██║  ██║╚███╔███╔╝██║ ╚████║');
  console.log('  ╚═╝  ╚═╝╚══════╝╚══════╝╚═╝     ╚═╝  ╚═╝ ╚══╝╚══╝ ╚═╝  ╚═══╝');
  console.log('');
  console.log('  ØSTFOLD OVERLAY SERVER');
  console.log('');
  console.log(`  Kontrollpanel:  http://localhost:${PORT}/KONTROLLPANEL.html`);
  console.log(`  Overlays (OBS): http://localhost:${PORT}/04_nameplates.html`);
  console.log(`                  http://localhost:${PORT}/07_multistream.html`);
  console.log(`                  http://localhost:${PORT}/08_interview.html  osv.`);
  console.log('');
  console.log('  Trykk Ctrl+C for å stoppe serveren.');
  console.log('');
});
